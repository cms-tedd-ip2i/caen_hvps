To run "CAEN HVPSS Channels Controller" type in command shell:

java -jar ChannelsController.jar <ip address> <username> <password>
